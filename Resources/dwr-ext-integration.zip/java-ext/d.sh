/opt/local/apache-tomcat-5-1.5.15/bin/shutdown.sh
ant deploy
/opt/local/apache-tomcat-5-1.5.15/bin/startup.sh
