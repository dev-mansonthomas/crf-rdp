package com.scottwalter.sandbox.bsl;

import java.util.List;
import com.scottwalter.sandbox.model.ToDoItem;
import com.scottwalter.sandbox.model.ListRange;

public interface ToDo {
	public ListRange getItems(String name, boolean flag, int start, int count, String orderBy);
}