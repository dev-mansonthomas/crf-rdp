package com.scottwalter.sandbox.bsl.impl;

import com.scottwalter.sandbox.bsl.ToDo;
import java.util.List;
import java.util.ArrayList;
import com.scottwalter.sandbox.model.ToDoItem;
import com.scottwalter.sandbox.model.ListRange;
import com.scottwalter.sandbox.model.Author;
public class ToDoImpl implements ToDo {
	
	public ListRange getItems(String name, boolean flag, int start, int count, String orderBy) {
		System.out.println("start=" + start + ";count=" + count + ";name=" + name + ";flag=" + flag);
		ListRange listRange = new ListRange();
		
		Object[] data = {new ToDoItem(1,"item1",new Author("Scott", "Walter")),new ToDoItem(2,"item2",new Author("Scott", "Walter")),new ToDoItem(3,"item3",new Author("Scott", "Walter")),new ToDoItem(4,"item4",new Author("Scott", "Walter")),new ToDoItem(5,"item5",new Author("Scott", "Walter"))};
		listRange.setData(data);
		listRange.setTotalSize(5555);
		
		return listRange;
		
	}
}