package com.scottwalter.sandbox.model;

import java.util.List;

public class ComplexObject {
	
	private List items;
	private int totalRows;
	
	public void setItems(List items) {this.items = items;}
	public List getItems() {return items;}
}