package com.scottwalter.sandbox.model;

public class ToDoItem {
	private int id;
	private String description;
	private Author author;
	
	public ToDoItem(int id, String description, Author author) {
		this.id = id;
		this.description = description;
		this.author = author;
	}
	
	public int getId() { return this.id;}
	public void setId(int id) { this.id = id;}
	
	public String getDescription() { return this.description; }
	public void setString(String description) { this.description = description; }	
	
	public Author getAuthor() { return this.author; }
	public void setAuthor(Author author) { this.author = author;}
}